<?php

// Connect to the database
$db = new mysqli('localhost', 'username', 'password', 'database_name');

// Handle front-end form submissions
if($_SERVER['REQUEST_METHOD'] == 'POST') {

  if($_POST['type'] == 'addStudent') {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    // Insert into students table
    $query = "INSERT INTO students (name, email) VALUES ('$name', '$email')";
    $db->query($query);

  } else if ($_POST['type'] == 'deleteStudent') {
    
    $id = $_POST['id'];
    
    // Delete student
    $query = "DELETE FROM students WHERE id=$id";
    $db->query($query);
    
  } else if ($_POST['type'] == 'updateStudent') {

    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Update student
    $query = "UPDATE students SET name='$name', email='$email' WHERE id=$id";
    $db->query($query);

  }

}

// Get data to display on front-end
$students = $db->query("SELECT * FROM students")->fetch_all(MYSQLI_ASSOC);

?>
// backend.php

// PHP CRUD logic

$students = $db->query("SELECT * FROM students")->fetch_all(MYSQLI_ASSOC);

?>

<!-- HTML -->

<table>

  <?php foreach ($students as $student): ?>
  
    <tr>
      <td><?=$student['name']?></td>
      <td><?=$student['email']?></td>
    </tr>

  <?php endforeach; ?>

</table>